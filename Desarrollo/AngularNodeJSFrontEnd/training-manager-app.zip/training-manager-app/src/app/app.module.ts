import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { CursosComponent } from './cursos/cursos.component';
import { FormCursosComponent } from './cursos/cursos/form-cursos.component';
import {Routes, RouterModule } from '@angular/router';
import {FormsModule} from '@angular/forms';
import { DescuentosComponent } from './descuentos/descuentos.component';
import { FormDescuentosComponent } from './descuentos/descuentos/form-descuentos.component';
import { ModalidadesComponent } from './modalidades/modalidades.component';
import { FormModalidadesComponent } from './modalidades/modalidad/form-modalidades.component';

const routes:Routes=[

  {path:'cursoList',redirectTo:'/cursos',pathMatch:'full'},
  {path:'cursos',component:CursosComponent},
  {path:'cursos/form',component:FormCursosComponent},
  {path:'cursos/form/:id',component:FormCursosComponent},

  {path:'descuentoList',redirectTo:'/descuentos',pathMatch:'full'},
  {path:'descuentos',component:DescuentosComponent},
  {path:'descuentos/form',component:FormDescuentosComponent},
  {path:'descuentos/form/:id',component:FormDescuentosComponent},

  {path:'modalidadList',redirectTo:'/modalidades',pathMatch:'full'},
  {path:'modalidades',component:ModalidadesComponent},
  {path:'modalidades/form',component:FormModalidadesComponent},
  {path:'modalidades/form/:id',component:FormModalidadesComponent}


]

@NgModule({
  declarations: [
    AppComponent,
    CursosComponent,
    FormCursosComponent,
    DescuentosComponent,
    FormDescuentosComponent,
    ModalidadesComponent,
    FormModalidadesComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
