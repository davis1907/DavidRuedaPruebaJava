import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Modalidad } from './modalidad';

@Injectable({
  providedIn: 'root'
})
export class ModalidadService {

  private url:string ="http://localhost:8095/rest/modalidades";
  private url2:string ="http://localhost:8095/rest/modalidad";
  constructor(private http:HttpClient) { }
  // obtener modalidads
  getAll():Observable<Modalidad[]>{
    return this.http.get<Modalidad[]>(this.url);
  }
  // crear modalidad
  create(modalidad:Modalidad):Observable<Modalidad>{
    return this.http.post<Modalidad>(this.url,modalidad);
  }
  //obtener un modalidad
  get(id:number):Observable<Modalidad>{
    return this.http.get<Modalidad>(this.url2+'/?idModalidad='+id);
  }
 // update modalidad
  update(modalidad:Modalidad):Observable<Modalidad>{
    return this.http.put<Modalidad>(this.url,modalidad);
  }
  //eliminar un estudiante
 //obtener un modalidad
  delete(id:number):Observable<Modalidad>{
    return this.http.delete<Modalidad>(this.url+'/?idModalidad='+id);
}
}
