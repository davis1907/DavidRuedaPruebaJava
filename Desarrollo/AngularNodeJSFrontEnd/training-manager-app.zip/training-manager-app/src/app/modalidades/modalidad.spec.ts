import { Modalidad } from './modalidad';

describe('Modalidad', () => {
  it('should create an instance', () => {
    expect(new Modalidad()).toBeTruthy();
  });
});
