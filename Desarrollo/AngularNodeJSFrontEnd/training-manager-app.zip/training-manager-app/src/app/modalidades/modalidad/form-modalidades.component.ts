import { Component, OnInit } from '@angular/core';
import { Modalidad } from '../modalidad';
import { ModalidadService } from '../modalidad.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-form-modalidades',
  templateUrl: './form-modalidades.component.html',
  styleUrls: ['./form-modalidades.component.css']
})
export class FormModalidadesComponent implements OnInit {

  modalidad:Modalidad = new  Modalidad();
  titulo:string = "Registro de Modalidades";
  constructor(private modalidadService:ModalidadService,private router:Router, private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.cargar();
  }

 cargar():void{
  console.log(this.modalidad);
  

  this.activatedRoute.params.subscribe(
      e=>{
        let id=e['id'];
        console.log('---------->' + id);
        if(id){
          this.modalidadService.get(id).subscribe(
            es=>this.modalidad=es
          );
        }
      }
  );

 }

  create():void{
    console.log(this.modalidad);
    this.modalidadService.create(this.modalidad).subscribe(
        res => this.router.navigate(['/modalidades'])
    );
  }

  update():void{
    this.modalidadService.update(this.modalidad).subscribe(
      res => this.router.navigate(['/modalidades'])
  );

  }

}
