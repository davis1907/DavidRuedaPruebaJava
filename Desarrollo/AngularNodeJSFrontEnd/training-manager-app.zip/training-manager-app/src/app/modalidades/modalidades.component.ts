import { Component, OnInit } from '@angular/core';
import { Modalidad } from './modalidad';
import { ModalidadService } from './modalidad.service';

@Component({
  selector: 'app-modalidades',
  templateUrl: './modalidades.component.html',
  styleUrls: ['./modalidades.component.css']
})
export class ModalidadesComponent implements OnInit {

  titulo:string = "Lista de Modalidades";
  
  modalidades: Modalidad[] =[];

  constructor(private modalidadService: ModalidadService){
  }

  ngOnInit():void{
      this.modalidadService.getAll().subscribe(
         e => this.modalidades= e
      );
    }
    
   delete(modalidad:Modalidad):void{
      console.log("hello from delete");
      this.modalidadService.delete(modalidad.id).subscribe(
         res=> this.modalidadService.getAll().subscribe(
            response => this.modalidades=response
         )
      );

   } 

}
