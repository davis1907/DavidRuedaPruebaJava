import { Component, OnInit } from '@angular/core';
import { Curso } from './curso';
import { CursoService } from './curso.service';

@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.component.html',
  styleUrls: ['./cursos.component.css']
})
export class CursosComponent implements OnInit {
  titulo:string = "Lista de Cursos";
  
  cursos: Curso[] =[];
  
  

  constructor(private cursoservice: CursoService){
  }

  ngOnInit():void{
      this.cursoservice.getAll().subscribe(
         e => this.cursos= e
      );
    }
    
   delete(curso:Curso):void{
      console.log("hello from delete");
      this.cursoservice.delete(curso.id).subscribe(
         res=> this.cursoservice.getAll().subscribe(
            response => this.cursos=response
         )
      );

   } 

}
