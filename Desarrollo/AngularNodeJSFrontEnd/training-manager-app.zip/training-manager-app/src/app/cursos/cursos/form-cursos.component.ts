import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Modalidad } from 'src/app/modalidades/modalidad';
import { ModalidadService } from 'src/app/modalidades/modalidad.service';
import { Curso } from '../curso';
import { CursoService } from '../curso.service';

@Component({
  selector: 'app-form-cursos',
  templateUrl: './form-cursos.component.html',
  styleUrls: ['./form-cursos.component.css']
})
export class FormCursosComponent implements OnInit {
  curso:Curso = new  Curso();
  titulo:string = "Registro de Cursos";
  constructor(private cursoService:CursoService,private router:Router, 
            private activatedRoute:ActivatedRoute, private modalidadService:ModalidadService) { }

  modalidades:Modalidad[] =[];
 
 selectedLevel = this.modalidades[0];

  ngOnInit(): void {
    this.cargar();

    this.modalidadService.getAll().subscribe(
      e => this.modalidades= e
   );

  }

 cargar():void{
  console.log(this.curso);
  

  this.activatedRoute.params.subscribe(
      e=>{
        let id=e['id'];
        console.log('---------->' + id);
        if(id){
          this.cursoService.get(id).subscribe(
            es=>this.curso=es
          );
        }
      }
  );

 }

  create():void{
    console.log(this.curso);
    this.cursoService.create(this.curso).subscribe(
        res => this.router.navigate(['/cursos'])
    );
  }

  update():void{
    this.cursoService.update(this.curso).subscribe(
      res => this.router.navigate(['/cursos'])
  );

    }

}
