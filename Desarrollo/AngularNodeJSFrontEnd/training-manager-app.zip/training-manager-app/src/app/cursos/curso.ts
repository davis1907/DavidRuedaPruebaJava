import { Modalidad } from "../modalidades/modalidad";

export class Curso {
    id:number = 0;
    nombre:string = "";
    costo:number = 0;
    descripcion:string="";
    horas:number=0;
    dirigidoA:string="";
    modalidad:Modalidad=new Modalidad();
    
}
