import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Curso } from './curso';

@Injectable({
  providedIn: 'root'
})
export class CursoService {
  private url:string ="http://localhost:8095/rest/cursos";
  private url2:string ="http://localhost:8095/rest/curso";
  constructor(private http:HttpClient) { }
  // obtener cursos
  getAll():Observable<Curso[]>{
    return this.http.get<Curso[]>(this.url);
  }
  // crear curso
  create(curso:Curso):Observable<Curso>{
    return this.http.post<Curso>(this.url,curso);
  }
  //obtener un curso
  get(id:number):Observable<Curso>{
    return this.http.get<Curso>(this.url2+'/?idCurso='+id);
  }
 // update curso
  update(curso:Curso):Observable<Curso>{
    return this.http.put<Curso>(this.url,curso);
  }
  //eliminar un estudiante
 //obtener un curso
  delete(id:number):Observable<Curso>{
    return this.http.delete<Curso>(this.url+'/?idCurso='+id);
}
}
