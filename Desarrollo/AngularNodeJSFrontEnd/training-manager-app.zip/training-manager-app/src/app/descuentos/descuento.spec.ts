import { Descuento } from './descuento';

describe('Descuento', () => {
  it('should create an instance', () => {
    expect(new Descuento()).toBeTruthy();
  });
});
