import { Curso } from "../cursos/curso";
import { Modalidad } from "../modalidades/modalidad";

export class Descuento {
    id:number = 0;
    nombre:string = "";
    descuento:number = 0;
    pais:string="";
    fechafinal:Date= new Date();
    modalidad:Modalidad= new Modalidad();
    curso:Curso=new Curso();
}


