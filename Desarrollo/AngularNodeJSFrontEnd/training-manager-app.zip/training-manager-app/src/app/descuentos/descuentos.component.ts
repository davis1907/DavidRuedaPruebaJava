import { Component, OnInit } from '@angular/core';
import { Descuento } from './descuento';
import { DescuentoService } from './descuento.service';



@Component({
  selector: 'app-descuentos',
  templateUrl: './descuentos.component.html',
  styleUrls: ['./descuentos.component.css']
})
export class DescuentosComponent implements OnInit {

  titulo:string = "Lista de Descuentos";
  
  descuentos: Descuento[] =[];

  constructor(private descuentoservice: DescuentoService){
  }

  ngOnInit():void{
      this.descuentoservice.getAll().subscribe(
         e => this.descuentos= e
      );
    }
    
   delete(descuento:Descuento):void{
      console.log("hello from delete");
      this.descuentoservice.delete(descuento.id).subscribe(
         res=> this.descuentoservice.getAll().subscribe(
            response => this.descuentos=response
         )
      );

   } 
}
