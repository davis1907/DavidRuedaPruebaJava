import { Injectable } from '@angular/core';
import { Descuento } from './descuento';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DescuentoService {

  private url:string ="http://localhost:8095/rest/descuentos";
  private url2:string ="http://localhost:8095/rest/descuento";
  constructor(private http:HttpClient) { }
  // obtener cursos
  getAll():Observable<Descuento[]>{
    return this.http.get<Descuento[]>(this.url);
  }
  // crear descuento
  create(descuento:Descuento):Observable<Descuento>{
    return this.http.post<Descuento>(this.url,descuento);
  }
  //obtener un descuento
  get(id:number):Observable<Descuento>{
    return this.http.get<Descuento>(this.url2+'/?idDescuento='+id);
  }
 // update descuento
  update(descuento:Descuento):Observable<Descuento>{
    return this.http.put<Descuento>(this.url,descuento);
  }
  //eliminar un estudiante
 //obtener un descuento
  delete(id:number):Observable<Descuento>{
    return this.http.delete<Descuento>(this.url+'/?idDescuento='+id);
}
}
