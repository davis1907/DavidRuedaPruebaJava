import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Descuento } from '../descuento';
import { DescuentoService } from '../descuento.service';

@Component({
  selector: 'app-form-descuentos',
  templateUrl: './form-descuentos.component.html',
  styleUrls: ['./form-descuentos.component.css']
})
export class FormDescuentosComponent implements OnInit {

  descuento:Descuento = new  Descuento();
  titulo:string = "Registro de Descuentos";
  constructor(private descuentoService:DescuentoService,private router:Router, private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.cargar();
  }

 cargar():void{
  console.log(this.descuento);
  

  this.activatedRoute.params.subscribe(
      e=>{
        let id=e['id'];
        console.log('---------->' + id);
        if(id){
          this.descuentoService.get(id).subscribe(
            es=>this.descuento=es
          );
        }
      }
  );

 }

  create():void{
    console.log(this.descuento);
    this.descuentoService.create(this.descuento).subscribe(
        res => this.router.navigate(['/descuentos'])
    );
  }

  update():void{
    this.descuentoService.update(this.descuento).subscribe(
      res => this.router.navigate(['/descuentos'])
  );

    }

}
